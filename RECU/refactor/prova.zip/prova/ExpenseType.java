package prova;

enum ExpenseType {
    DINNER, BREAKFAST, CAR_RENTAL
}
