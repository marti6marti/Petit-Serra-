package prova;

public class Expense {
    ExpenseType type;
    int amount;
}
